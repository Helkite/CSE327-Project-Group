# Gore-Gore-an-ecommerce-site
This project made by PHP, CSS, HTML, JS and MYSQL.
There has a proper web tech project with mysql server.
At first you need to coppyy all the files in to "C:\xampp\htdocs" this folder.
Then you need to create a database in mysql named "gore gore".
Then import "gore_gore.sql" file.
Thats all, after that you can run this web site properly.
Thank you for show my project.
