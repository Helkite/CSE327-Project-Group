<?php
  session_start();
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Settings</title>
    <!-- <link rel="stylesheet" type="text/css" href="setting.css"> -->
  </head>
  <body>
    <?php include('header.php'); ?>
    <?php include('navBar.php');?>
    <?php include('editProfile.php'); ?>
    
    <?php include('footer.php'); ?>
  </body>
</html>
