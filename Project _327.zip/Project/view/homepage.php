
<!DOCTYPE html>
<html>
<head>
	<title>Gore Gore - Your Online Shopping Destination</title>
	<link rel="stylesheet" type="text/css" href="homepage.css">
</head>
<body>
	<!-- <?php include('header.php'); ?> -->

	<?php include('product.php'); ?>

	<!-- <?php include('footer.php'); ?> -->

</body>
</html>
