<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="footer.css">
</head>
<body>
	<footer>
		<div class="container">
			<p>&copy; 2023 Gore Gore. All rights reserved.</p>
			<nav>
				<ul>
					<li><a href="#">Privacy Policy</a></li>
					<li><a href="#">Terms and Conditions</a></li>
				</ul>
			</nav>
		</div>
	</footer>
</body>
</html>